'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/darealist2021/DAREALIST-BUILDS/refs/heads/main/Darealistbuildsnew.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/darealist2021/DAREALIST-BUILDS/refs/heads/main/darealistnotify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
