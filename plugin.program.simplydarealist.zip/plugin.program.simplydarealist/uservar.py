'''#####-----Build File-----#####'''
buildfile = 'http://CHANGEME'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://CHANGEME'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
